package com.gua.crosshair

import android.content.Context
import android.graphics.*
import android.view.View

class CrosshairView(c: Context) : View(c) {
    var model = 0
    var color = Color.RED
    var size = 40
    var thick = 4
    var opacity = 100

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = size * d
        val t = thick * d
        val g = s * 0.35f
        p.color = color
        p.alpha = opacity * 255 / 100
        p.strokeWidth = t
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.STROKE
        when (model) {
            0 -> { p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, t * 1.2f, p) } // Dot
            1 -> { cv.drawLine(cx - s, cy, cx + s, cy, p); cv.drawLine(cx, cy - s, cx, cy + s, p) } // Plus
            2 -> { // Plus gap
                cv.drawLine(cx - s, cy, cx - g, cy, p); cv.drawLine(cx + g, cy, cx + s, cy, p)
                cv.drawLine(cx, cy - s, cx, cy - g, p); cv.drawLine(cx, cy + g, cx, cy + s, p)
            }
            3 -> cv.drawCircle(cx, cy, s * 0.6f, p) // Circle
            4 -> { // Circle + dot
                cv.drawCircle(cx, cy, s * 0.6f, p)
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, t * 0.9f, p)
            }
            5 -> { // X
                val k = s * 0.7f
                cv.drawLine(cx - k, cy - k, cx + k, cy + k, p); cv.drawLine(cx - k, cy + k, cx + k, cy - k, p)
            }
            6 -> { // T shape
                cv.drawLine(cx - s, cy, cx + s, cy, p); cv.drawLine(cx, cy, cx, cy + s, p)
            }
            7 -> cv.drawRect(cx - s * 0.6f, cy - s * 0.6f, cx + s * 0.6f, cy + s * 0.6f, p) // Square
            8 -> { // Plus gap + dot
                cv.drawLine(cx - s, cy, cx - g, cy, p); cv.drawLine(cx + g, cy, cx + s, cy, p)
                cv.drawLine(cx, cy - s, cx, cy - g, p); cv.drawLine(cx, cy + g, cx, cy + s, p)
                p.style = Paint.Style.FILL; cv.drawCircle(cx, cy, t * 0.8f, p)
            }
            9 -> { // Chevron ^
                val k = s * 0.6f
                cv.drawLine(cx - k, cy + k * 0.6f, cx, cy - k * 0.4f, p); cv.drawLine(cx, cy - k * 0.4f, cx + k, cy + k * 0.6f, p)
            }
            10 -> { // Diamond
                val k = s * 0.6f
                val path = Path().apply { moveTo(cx, cy - k); lineTo(cx + k, cy); lineTo(cx, cy + k); lineTo(cx - k, cy); close() }
                cv.drawPath(path, p)
            }
            11 -> { // Big circle + plus gap
                cv.drawCircle(cx, cy, s * 0.8f, p)
                cv.drawLine(cx - s * 0.4f, cy, cx + s * 0.4f, cy, p); cv.drawLine(cx, cy - s * 0.4f, cx, cy + s * 0.4f, p)
            }
        }
    }
}
