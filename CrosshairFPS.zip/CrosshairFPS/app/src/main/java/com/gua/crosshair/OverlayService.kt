package com.gua.crosshair

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    companion object { var running = false }

    private lateinit var wm: WindowManager
    private var cross: CrosshairView? = null
    private var fpsTv: TextView? = null
    private var frames = 0
    private var last = 0L

    private val cb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) {
            if (last == 0L) last = t
            frames++
            if (t - last >= 1_000_000_000L) {
                fpsTv?.text = "FPS: $frames"
                frames = 0
                last = t
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "overlay"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(ch, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Crosshair FPS aktif")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n)
        if (!running) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            running = true
            Choreographer.getInstance().postFrameCallback(cb)
        }
        apply()
        return START_STICKY
    }

    private fun lp(w: Int, h: Int, g: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = g }

    private fun apply() {
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val size = sp.getInt("size", 40)
        val dim = ((size * 2 + 30) * d).toInt()

        if (cross == null) {
            cross = CrosshairView(this)
            wm.addView(cross, lp(dim, dim, Gravity.CENTER))
        }
        cross!!.apply {
            model = sp.getInt("model", 0)
            color = sp.getInt("color", Color.RED)
            this.size = size
            thick = sp.getInt("thick", 4)
            opacity = sp.getInt("opacity", 100)
            invalidate()
        }
        wm.updateViewLayout(cross, lp(dim, dim, Gravity.CENTER))

        if (sp.getBoolean("fps", true)) {
            if (fpsTv == null) {
                fpsTv = TextView(this).apply {
                    text = "FPS: --"
                    setTextColor(Color.GREEN)
                    textSize = 14f
                    setBackgroundColor(Color.argb(120, 0, 0, 0))
                    setPadding(12, 4, 12, 4)
                }
                val l = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START)
                l.x = (24 * d).toInt(); l.y = (8 * d).toInt()
                wm.addView(fpsTv, l)
            }
        } else {
            fpsTv?.let { wm.removeView(it) }
            fpsTv = null
        }
    }

    override fun onDestroy() {
        Choreographer.getInstance().removeFrameCallback(cb)
        cross?.let { wm.removeView(it) }
        fpsTv?.let { wm.removeView(it) }
        cross = null; fpsTv = null
        running = false
        super.onDestroy()
    }
}
