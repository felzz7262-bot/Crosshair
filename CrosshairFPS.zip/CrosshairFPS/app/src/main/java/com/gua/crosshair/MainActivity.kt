package com.gua.crosshair

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var sp: SharedPreferences

    private val models = arrayOf(
        "Dot", "Plus", "Plus + Gap", "Circle", "Circle + Dot", "X",
        "T-Shape", "Square", "Plus Gap + Dot", "Chevron", "Diamond", "Circle + Plus"
    )
    private val colors = intArrayOf(
        Color.RED, Color.GREEN, Color.CYAN, Color.YELLOW, Color.MAGENTA,
        Color.WHITE, Color.parseColor("#FF8800"), Color.parseColor("#0066FF"),
        Color.parseColor("#FF66AA"), Color.BLACK
    )

    private fun refresh() {
        if (OverlayService.running) startForegroundService(Intent(this, OverlayService::class.java))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, pad, 0, 8) }

        root.addView(TextView(this).apply { text = "Crosshair + FPS Overlay"; textSize = 22f })

        // Model
        root.addView(label("Model crosshair"))
        val sc = Spinner(this)
        sc.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models)
        sc.setSelection(sp.getInt("model", 0))
        sc.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                sp.edit().putInt("model", pos).apply(); refresh()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(sc)

        // Warna
        root.addView(label("Warna"))
        val row = LinearLayout(this)
        val hs = HorizontalScrollView(this).apply { addView(row) }
        colors.forEach { c ->
            row.addView(Button(this).apply {
                setBackgroundColor(c)
                layoutParams = LinearLayout.LayoutParams((48 * d).toInt(), (48 * d).toInt()).apply { setMargins(6, 6, 6, 6) }
                setOnClickListener { sp.edit().putInt("color", c).apply(); refresh() }
            })
        }
        root.addView(hs)

        fun seek(name: String, key: String, min: Int, max: Int, def: Int) {
            root.addView(label(name))
            root.addView(SeekBar(this).apply {
                this.max = max - min
                progress = sp.getInt(key, def) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, v: Int, u: Boolean) {
                        if (u) { sp.edit().putInt(key, v + min).apply(); refresh() }
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }
        seek("Ukuran", "size", 10, 120, 40)
        seek("Ketebalan", "thick", 1, 12, 4)
        seek("Transparansi (opacity)", "opacity", 10, 100, 100)

        // FPS
        root.addView(Switch(this).apply {
            text = "Tampilkan FPS"
            isChecked = sp.getBoolean("fps", true)
            setPadding(0, pad, 0, pad)
            setOnCheckedChangeListener { _, c -> sp.edit().putBoolean("fps", c).apply(); refresh() }
        })

        // Start / Stop
        root.addView(Button(this).apply {
            text = "START OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(context, "Aktifin izin 'Tampil di atas aplikasi lain' dulu", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "STOP OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
    }
}
